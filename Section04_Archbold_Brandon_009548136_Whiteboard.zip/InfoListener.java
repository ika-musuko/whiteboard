// interface for listening to DShapes if their info is changed
public interface InfoListener {
	public void infoChanged(Info info); 	
}
