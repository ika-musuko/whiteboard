import java.util.List;
interface CanvasListener {
    public void canvasChanged(List<DShape> shapeList);
}